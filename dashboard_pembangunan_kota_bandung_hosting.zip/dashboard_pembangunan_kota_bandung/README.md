# Dashboard Visualisasi dan Analisis Data Pembangunan Kota Bandung

Prototype project magang berbasis Python + Streamlit.

## 1. Instalasi
Pastikan Python 3.10+ sudah terpasang.

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Linux/macOS:
```bash
source venv/bin/activate
```

Install library:
```bash
pip install -r requirements.txt
```

## 2. Menjalankan aplikasi

```bash
streamlit run app.py
```

Browser akan membuka alamat lokal Streamlit.

## 3. Mengganti data
Ganti file:
`data/data_pembangunan_bandung.csv`

Kolom yang digunakan:
- Tahun
- Bidang
- Indikator
- Wilayah
- Nilai
- Target
- Satuan
- Arah
- Sumber

`Nilai` dan `Target` harus berupa angka. Jika target tidak tersedia, logika monitoring perlu disesuaikan.

## 4. Modul
- Dashboard
- Monitoring Indikator
- Analisis Tren
- Analisis Wilayah
- Detail Indikator
- Data & Export

## 5. Pengembangan untuk magang
- Ganti dataset contoh dengan data resmi yang diizinkan instansi.
- Tambahkan login jika dibutuhkan.
- Gunakan MySQL/PostgreSQL jika data sudah besar.
- Tambahkan peta kecamatan/kelurahan jika tersedia shapefile/GeoJSON.
- Tambahkan modul early warning.
- Tambahkan dokumentasi sumber dan definisi setiap indikator.
