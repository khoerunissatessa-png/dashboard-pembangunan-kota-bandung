import os
import streamlit as st
import pandas as pd
import plotly.express as px
from io import BytesIO

st.set_page_config(
    page_title="Dashboard Pembangunan Kota Bandung",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "data", "data_pembangunan_bandung.csv")

@st.cache_data
def load_data():
    df = pd.read_csv(DATA_PATH)
    df.columns = [c.strip() for c in df.columns]
    for col in ["Tahun", "Nilai", "Target"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["Capaian_%"] = (df["Nilai"] / df["Target"] * 100).round(2)
    df["Perubahan_%"] = (
        df.sort_values(["Indikator", "Wilayah", "Tahun"])
          .groupby(["Indikator", "Wilayah"])["Nilai"]
          .pct_change() * 100
    ).round(2)
    return df

def status_capaian(row):
    target = row["Target"]
    nilai = row["Nilai"]
    arah = row.get("Arah", "Semakin tinggi semakin baik")
    if pd.isna(target) or target == 0:
        return "Tidak tersedia"
    capaian = nilai / target * 100
    if arah == "Semakin rendah semakin baik":
        if nilai <= target:
            return "Tercapai"
        elif nilai <= target * 1.10:
            return "Mendekati target"
        return "Perlu perhatian"
    if capaian >= 100:
        return "Tercapai"
    if capaian >= 80:
        return "Mendekati target"
    return "Perlu perhatian"

def to_excel(df):
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Data")
    return output.getvalue()

try:
    df = load_data()
except Exception as e:
    st.error(f"Data gagal dimuat: {e}")
    st.stop()

df["Status"] = df.apply(status_capaian, axis=1)

st.sidebar.title("📊 Dashboard Pembangunan")
st.sidebar.caption("Kota Bandung")

menu = st.sidebar.radio(
    "Menu",
    ["Dashboard", "Monitoring Indikator", "Analisis Tren", "Analisis Wilayah", "Detail Indikator", "Data & Export"],
)

st.sidebar.markdown("---")
st.sidebar.info("Data Yang di Gunakan yaitu bidang ekonomi, bidang sosial, bidang kesehatan dan bidang ketenagakerjaan.")

# ---------------- DASHBOARD ----------------
if menu == "Dashboard":
    st.title("Dashboard Visualisasi dan Analisis Data Pembangunan Kota Bandung")
    st.write("Dashboard untuk memantau perkembangan indikator pembangunan berdasarkan tahun, bidang, indikator, dan wilayah.")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Jumlah Indikator", df["Indikator"].nunique())
    c2.metric("Jumlah Wilayah", df["Wilayah"].nunique())
    c3.metric("Tahun Terakhir", int(df["Tahun"].max()))
    c4.metric("Rata-rata Capaian", f"{df['Capaian_%'].mean():.1f}%")

    st.markdown("### Filter Dashboard")
    f1, f2, f3 = st.columns(3)
    tahun = f1.selectbox("Tahun", sorted(df["Tahun"].unique(), reverse=True))
    bidang = f2.selectbox("Bidang", ["Semua"] + sorted(df["Bidang"].unique().tolist()))
    indikator = f3.selectbox("Indikator", ["Semua"] + sorted(df["Indikator"].unique().tolist()))

    filtered = df[df["Tahun"] == tahun].copy()
    if bidang != "Semua":
        filtered = filtered[filtered["Bidang"] == bidang]
    if indikator != "Semua":
        filtered = filtered[filtered["Indikator"] == indikator]

    s1, s2, s3, s4 = st.columns(4)
    s1.metric("Data Ditampilkan", len(filtered))
    s2.metric("Tercapai", int((filtered["Status"] == "Tercapai").sum()))
    s3.metric("Mendekati Target", int((filtered["Status"] == "Mendekati target").sum()))
    s4.metric("Perlu Perhatian", int((filtered["Status"] == "Perlu perhatian").sum()))

    if not filtered.empty:
        chart = px.bar(
            filtered.sort_values("Capaian_%"),
            x="Capaian_%",
            y="Indikator",
            color="Status",
            orientation="h",
            title=f"Capaian Indikator Tahun {tahun}",
            labels={"Capaian_%": "Capaian (%)", "Indikator": "Indikator"},
        )
        st.plotly_chart(chart, use_container_width=True)

        left, right = st.columns(2)
        with left:
            bidang_df = filtered.groupby("Bidang", as_index=False)["Nilai"].mean()
            fig = px.bar(bidang_df, x="Bidang", y="Nilai", title="Rata-rata Nilai per Bidang")
            st.plotly_chart(fig, use_container_width=True)
        with right:
            status_df = filtered["Status"].value_counts().reset_index()
            status_df.columns = ["Status", "Jumlah"]
            fig = px.pie(status_df, names="Status", values="Jumlah", title="Distribusi Status Capaian")
            st.plotly_chart(fig, use_container_width=True)

# ---------------- MONITORING ----------------
elif menu == "Monitoring Indikator":
    st.title("📌 Monitoring Indikator")
    st.write("Membandingkan target, nilai realisasi, capaian, dan status indikator.")

    indikator = st.selectbox("Pilih indikator", sorted(df["Indikator"].unique()))
    wilayah = st.selectbox("Pilih wilayah", ["Semua"] + sorted(df["Wilayah"].unique().tolist()))

    temp = df[df["Indikator"] == indikator].copy()
    if wilayah != "Semua":
        temp = temp[temp["Wilayah"] == wilayah]

    if not temp.empty:
        latest_year = temp["Tahun"].max()
        latest = temp[temp["Tahun"] == latest_year]
        avg_target = latest["Target"].mean()
        avg_value = latest["Nilai"].mean()
        avg_capaian = latest["Capaian_%"].mean()
        status = latest["Status"].mode().iloc[0]

        a, b, c, d = st.columns(4)
        a.metric("Tahun", int(latest_year))
        b.metric("Rata-rata Target", f"{avg_target:.2f}")
        c.metric("Rata-rata Realisasi", f"{avg_value:.2f}")
        d.metric("Capaian", f"{avg_capaian:.2f}%", status)

        fig = px.bar(
            temp,
            x="Tahun",
            y=["Target", "Nilai"],
            barmode="group",
            title=f"Target vs Realisasi — {indikator}",
            labels={"value": "Nilai", "variable": "Jenis"},
        )
        st.plotly_chart(fig, use_container_width=True)

        st.dataframe(
            temp[["Tahun", "Wilayah", "Target", "Nilai", "Capaian_%", "Status"]].sort_values(["Tahun", "Wilayah"]),
            use_container_width=True,
            hide_index=True,
        )

# ---------------- TREND ----------------
elif menu == "Analisis Tren":
    st.title("📈 Analisis Tren")
    indikator = st.selectbox("Pilih indikator", sorted(df["Indikator"].unique()))
    wilayah = st.selectbox("Wilayah", ["Semua"] + sorted(df["Wilayah"].unique().tolist()))

    temp = df[df["Indikator"] == indikator].copy()
    if wilayah != "Semua":
        temp = temp[temp["Wilayah"] == wilayah]

    trend = temp.groupby("Tahun", as_index=False)["Nilai"].mean().sort_values("Tahun")
    if len(trend) >= 2:
        trend["Perubahan_%"] = trend["Nilai"].pct_change().mul(100).round(2)
        arah = "meningkat" if trend.iloc[-1]["Nilai"] > trend.iloc[0]["Nilai"] else "menurun"
    else:
        trend["Perubahan_%"] = None
        arah = "belum dapat ditentukan"

    st.metric("Arah tren keseluruhan", arah.capitalize())
    fig = px.line(trend, x="Tahun", y="Nilai", markers=True, title=f"Tren {indikator}")
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Ringkasan Perubahan")
    st.dataframe(trend, use_container_width=True, hide_index=True)

# ---------------- WILAYAH ----------------
elif menu == "Analisis Wilayah":
    st.title("🗺️ Analisis Wilayah")
    tahun = st.selectbox("Tahun", sorted(df["Tahun"].unique(), reverse=True))
    indikator = st.selectbox("Indikator", sorted(df["Indikator"].unique()))

    temp = df[(df["Tahun"] == tahun) & (df["Indikator"] == indikator)].copy()
    temp = temp.sort_values("Nilai", ascending=False)

    if not temp.empty:
        fig = px.bar(
            temp,
            x="Wilayah",
            y="Nilai",
            title=f"Perbandingan {indikator} Antar Wilayah — {tahun}",
            text_auto=".2f",
        )
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(temp[["Wilayah", "Nilai", "Target", "Capaian_%", "Status"]], use_container_width=True, hide_index=True)

        highest = temp.iloc[0]
        lowest = temp.iloc[-1]
        st.info(f"Nilai tertinggi: {highest['Wilayah']} ({highest['Nilai']:.2f}). Nilai terendah: {lowest['Wilayah']} ({lowest['Nilai']:.2f}).")

# ---------------- DETAIL ----------------
elif menu == "Detail Indikator":
    st.title("🔎 Detail Indikator")
    indikator = st.selectbox("Pilih indikator", sorted(df["Indikator"].unique()))
    temp = df[df["Indikator"] == indikator].sort_values(["Tahun", "Wilayah"])
    row = temp.iloc[-1]

    st.subheader(indikator)
    st.write(f"**Bidang:** {row['Bidang']}  ")
    st.write(f"**Satuan:** {row['Satuan']}  ")
    st.write(f"**Arah indikator:** {row['Arah']}  ")
    st.write(f"**Sumber:** {row['Sumber']}")

    a, b, c = st.columns(3)
    a.metric("Nilai terakhir", f"{row['Nilai']:.2f}")
    b.metric("Target terakhir", f"{row['Target']:.2f}")
    c.metric("Status", row["Status"])

    fig = px.line(temp, x="Tahun", y="Nilai", color="Wilayah", markers=True, title="Perkembangan Indikator")
    st.plotly_chart(fig, use_container_width=True)
    st.dataframe(temp, use_container_width=True, hide_index=True)

# ---------------- DATA ----------------
else:
    st.title("📥 Data & Export")
    st.write("Gunakan filter untuk menampilkan data yang ingin diunduh.")
    f1, f2 = st.columns(2)
    tahun = f1.multiselect("Tahun", sorted(df["Tahun"].unique()), default=sorted(df["Tahun"].unique()))
    bidang = f2.multiselect("Bidang", sorted(df["Bidang"].unique()), default=sorted(df["Bidang"].unique()))

    temp = df[df["Tahun"].isin(tahun) & df["Bidang"].isin(bidang)].copy()
    st.dataframe(temp, use_container_width=True, hide_index=True)

    st.download_button(
        "⬇️ Download CSV",
        data=temp.to_csv(index=False).encode("utf-8"),
        file_name="data_pembangunan_bandung.csv",
        mime="text/csv",
    )
    st.download_button(
        "⬇️ Download Excel",
        data=to_excel(temp),
        file_name="data_pembangunan_bandung.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
