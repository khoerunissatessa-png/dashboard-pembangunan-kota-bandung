# Hosting Dashboard Pembangunan Kota Bandung

Aplikasi ini menggunakan **Python + Streamlit** dan siap di-host di **Streamlit Community Cloud**.

## Struktur yang wajib dipertahankan

- `app.py` — aplikasi utama
- `requirements.txt` — library Python
- `data/data_pembangunan_bandung.csv` — dataset
- `.streamlit/config.toml` — konfigurasi Streamlit

## Cara hosting gratis dengan Streamlit Community Cloud

1. Buat akun/login GitHub.
2. Buat repository baru, misalnya `dashboard-pembangunan-kota-bandung`.
3. Upload **isi folder** `dashboard_pembangunan_kota_bandung` ke repository tersebut. Jangan upload file ZIP sebagai satu-satunya isi repository.
4. Buka Streamlit Community Cloud.
5. Pilih **Create app / Deploy an app**.
6. Pilih repository GitHub yang tadi dibuat.
7. Pada **Main file path**, isi:
   `app.py`
8. Klik **Deploy**.
9. Setelah selesai, Streamlit akan memberikan alamat web publik untuk dashboard.

## Jika repository menggunakan folder project

Jika `app.py` berada di:
`dashboard_pembangunan_kota_bandung/app.py`

maka pada **Main file path** gunakan:
`dashboard_pembangunan_kota_bandung/app.py`

## Menjalankan di komputer

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Catatan dataset

Path dataset pada aplikasi adalah:

`data/data_pembangunan_bandung.csv`

Karena itu folder `data` harus ikut di-upload ke GitHub.

## Aman untuk hosting

- Tidak menggunakan database lokal.
- Tidak memerlukan API key.
- Tidak memerlukan file `.env`.
- Dataset dibaca dari folder project.
- Download CSV/Excel dilakukan langsung dari aplikasi.
